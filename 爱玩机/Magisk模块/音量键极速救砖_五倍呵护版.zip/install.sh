##########################################################################################
#
# Magisk Module Template Config Script
# by 小白杨
#
##########################################################################################
##########################################################################################
#
# Instructions:
#
# 1. Place your files into system folder (delete the placeholder file)
# 2. Fill in your module's info into module.prop
# 3. Configure the settings in this file (config.sh)
# 4. If you need boot scripts, add them into common/post-fs-data.sh or common/service.sh
# 5. Add your additional or modified system properties into common/system.prop
#
##########################################################################################

##########################################################################################
# Configs
##########################################################################################

# Set to true if you need to enable Magic Mount
# Most mods would like it to be enabled
SKIPMOUNT=false
#是否安装模块后自动关闭，改为true，安装后不会自动勾选启用
LATESTARTSERVICE=true
POSTFSDATA=false
PROPFILE=false
##########################################################################################
# Installation Message
##########################################################################################

# Set what you want to show when installing your mod

print_modname() {
  ui_print "*******************************"
  ui_print "     	Magisk Module        "
  ui_print "    For    By 小白杨"
  ui_print "*******************************"
}

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info about how Magic Mount works, and why you need this

# This is an example
REPLACE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here, it will override the example above
# !DO NOT! remove this if you don't need to replace anything, leave it empty as it is now
REPLACE="

"
#添加您要精简的APP/文件夹目录
#例如：精简状态栏，找到状态栏目录为  /system/priv-app/SystemUI/SystemUI.apk
#转化加入:/system/priv-app/SystemUI
#（可以搭配高级设置获取APP目录）

##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
# MAGISK_VER (string): the version string of current installed Magisk
# MAGISK_VER_CODE (int): the version code of current installed Magisk
# BOOTMODE (bool): true if the module is currently installing in Magisk Manager
# MODPATH (path): the path where your module files should be installed
# TMPDIR (path): a place where you can temporarily store files
# ZIPFILE (path): your module's installation zip
# ARCH (string): the architecture of the device. Value is either arm, arm64, x86, or x64
# IS64BIT (bool): true if $ARCH is either arm64 or x64
# API (int): the API level (Android version) of the device
#

on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2

  require_api

  ui_print "- 清理缓存完毕"
}

set_permissions() {
  # Only some special files require specific permissions
  # The default permissions should be good enough for most cases

  # Here are some examples for the set_perm functions:

  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm_recursive  $MODPATH/system/lib       0       0       0755            0644

  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  # set_perm  $MODPATH/system/bin/app_process32   0       2000    0755         u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0       2000    0755         u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0       0       0644

  # The following is default permissions, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0777 0777

  #设置权限，基本不要去动
}

##########################################################################################
# Custom Functions
##########################################################################################

# This file (config.sh) will be sourced by the main flash script after util_functions.sh
# If you need custom logic, please add them here as functions, and call these functions in
# update-binary. Refrain from adding code directly into update-binary, as it will make it
# difficult for you to migrate your modules to newer template versions.
# Make update-binary as clean as possible, try to only do function calls in it.

require_api() {
  ui_print "*******************************"

  abi=$(getprop ro.product.cpu.abi)
  ui_print "- 设备处理器类型: $abi"

  case $abi in
  arm64*) ARCH=arm64 ;;
  arm*) ARCH=arm ;;
  x86_64*) ARCH=x86_64 ;;
  x86*) ARCH=x86 ;;
  mips64*) ARCH=mips64 ;;
  mips*) ARCH=mips ;;
  *) abort "未知处理器" ;;
  esac

  if [[ "$ARCH" == arm64 ]]; then

    keycheckPath=$MODPATH/system/bin/arm/keycheck
    ui_print "- 正在安装: ${abi}监听器"

  elif [[ "$ARCH" == arm ]]; then
    keycheckPath=$MODPATH/system/bin/arm/keycheck
    ui_print "- 正在安装: ${abi}监听器"

  elif [[ "$ARCH" == x86_64 ]]; then
    keycheckPath=$MODPATH/system/bin/x86/keycheck
    ui_print "- 正在安装: ${abi}监听器"

  elif
    [[ "$ARCH" == x86 ]]
  then
    keycheckPath=$MODPATH/system/bin/x86/keycheck
    ui_print "- 正在安装: ${abi}监听器"

  elif [[ "$ARCH" == mips64 ]]; then
    abort "暂时未支持处理器"

  elif [[ "$ARCH" == mips ]]; then
    abort "暂时未支持处理器"
  else
    abort "未知处理器"

  fi
  ui_print "*******************************"

    if [ -f $keycheckPath ]; then
      mv $keycheckPath $MODPATH
      rm -r $MODPATH/system
      ui_print "- 清理缓存完毕"
    else

      abort "监听文件丢失！"

    fi

}
