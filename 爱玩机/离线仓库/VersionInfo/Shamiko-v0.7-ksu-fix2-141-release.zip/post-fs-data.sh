MODDIR=${0%/*}

if [ "$(which magisk)" ]; then
  touch "$MODDIR/disable"
fi
