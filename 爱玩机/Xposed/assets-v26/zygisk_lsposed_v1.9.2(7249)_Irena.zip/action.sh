am broadcast -a "android.provider.Telephony.SECRET_CODE" -a "android.telephony.action.SECRET_CODE" -d "android_secret_code://5776733" "android"
